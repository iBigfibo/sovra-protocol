# Sovra Protocol — Multi-Chain Deployment Guide

## Contracts
- `MockUSDC_multichain.sol` — Deploy first on each testnet
- `SovraVault_multichain.sol` — Deploy 3 times per chain (svNG, svTR, svAR)

---

## Step 1 — Add Network to MetaMask

| Chain | ChainID | RPC URL | Faucet |
|---|---|---|---|
| Ethereum Sepolia ✅ | 11155111 | Already done | sepoliafaucet.com |
| Mantra Testnet | 9001 | https://rpc.testnet.mantrachain.io | faucet.testnet.mantrachain.io |
| Plume Testnet | 98864 | https://testnet-rpc.plumenetwork.xyz | faucet.plumenetwork.xyz |
| Base Sepolia | 84532 | https://sepolia.base.org | basefaucet.com |
| Arbitrum Sepolia | 421614 | https://sepolia-rollup.arbitrum.io/rpc | faucet.arbitrum.io |
| Polygon Amoy | 80002 | https://rpc-amoy.polygon.technology | faucet.polygon.technology |
| BNB Testnet | 97 | https://data-seed-prebsc-1-s1.binance.org:8545 | testnet.binance.org/faucet |
| Celo Alfajores | 44787 | https://alfajores-forno.celo-testnet.org | faucet.celo.org |
| Optimism Sepolia | 11155420 | https://sepolia.optimism.io | faucet.optimism.io |
| Scroll Sepolia | 534351 | https://sepolia-rpc.scroll.io | scroll.io/bridge |

---

## Step 2 — Deploy MockUSDC

In Remix:
1. Open `MockUSDC_multichain.sol`
2. Compile with Solidity 0.8.20
3. Switch MetaMask to target chain
4. Deploy — no constructor args needed
5. **Save the deployed address** — you need it for vault deployment

---

## Step 3 — Deploy SovraVault (x3 per chain)

Deploy 3 separate instances with these constructor args:

### svNG — Nigeria Vault
```
_usdc:        [MockUSDC address from Step 2]
_treasury:    [your wallet address]
_name:        "Sovra Nigeria Vault"
_symbol:      "svNG"
_baseAprBps:  2000
_fxRate:      135000
_fxSymbol:    "NGN"
_isTestnet:   true
```

### svTR — Turkey Vault
```
_usdc:        [MockUSDC address from Step 2]
_treasury:    [your wallet address]
_name:        "Sovra Turkey Vault"
_symbol:      "svTR"
_baseAprBps:  2700
_fxRate:      4500
_fxSymbol:    "TRY"
_isTestnet:   true
```

### svAR — Argentina Vault
```
_usdc:        [MockUSDC address from Step 2]
_treasury:    [your wallet address]
_name:        "Sovra Argentina Vault"
_symbol:      "svAR"
_baseAprBps:  4000
_fxRate:      140000
_fxSymbol:    "ARS"
_isTestnet:   true
```

---

## Step 4 — Whitelist Vaults as Minters

After deploying all 3 vaults, call on MockUSDC:
```
addMinter([svNG vault address])
addMinter([svTR vault address])
addMinter([svAR vault address])
```

---

## Step 5 — Update Frontend

In `index.html` find the contract addresses section and add the new chain:

```javascript
const NETWORKS = {
  11155111: { // Sepolia (existing)
    name: "Sepolia",
    usdc: "0x...",
    vaults: {
      svNG: "0x...",
      svTR: "0x...",
      svAR: "0x..."
    }
  },
  9001: { // Mantra (new)
    name: "Mantra Testnet",
    usdc: "0x...",
    vaults: {
      svNG: "0x...",
      svTR: "0x...",
      svAR: "0x..."
    }
  }
  // Add more chains here
}
```

---

## Step 6 — Verify Contracts (Optional but Recommended for Grants)

Each chain has its own block explorer. After deploying:
1. Go to the chain's explorer (e.g. sepolia.etherscan.io)
2. Find your contract address
3. Click "Verify and Publish"
4. Paste the source code
5. Green checkmark appears ✅

Verified contracts = more credibility with grant committees.

---

## Deployment Checklist Per Chain

- [ ] Network added to MetaMask
- [ ] Testnet gas tokens from faucet
- [ ] MockUSDC deployed + address saved
- [ ] svNG vault deployed + address saved
- [ ] svTR vault deployed + address saved
- [ ] svAR vault deployed + address saved
- [ ] All 3 vaults whitelisted as minters on MockUSDC
- [ ] Contracts verified on explorer
- [ ] Frontend updated with new addresses
- [ ] Grant application submitted

---

## What to Say in Grant Applications

> "Sovra Protocol is deployed on [Chain Name] testnet at the following addresses:
> MockUSDC: 0x...
> svNG Vault: 0x...
> svTR Vault: 0x...
> svAR Vault: 0x...
> Live testnet: sovra-protocol.vercel.app"
